


# from nombre_archivo.py importamos la funcion que requerimos
from saludar import saludar, adios


saludar()

adios()


