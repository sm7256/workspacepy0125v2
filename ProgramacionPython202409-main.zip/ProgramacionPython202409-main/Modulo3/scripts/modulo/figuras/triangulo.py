

def mostrar_triangulo(altura: int):
    """
    Muestra un triangulo rectangulo de altura n
    """
    for i in range(1, altura+1):
        print('#'*i)