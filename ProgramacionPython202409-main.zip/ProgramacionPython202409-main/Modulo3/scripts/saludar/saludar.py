def saludar():
    print("Hola, te estoy saludando desde la función saludar() " \
            "del módulo saludos")


def adios():
    print("Adios, te estoy despidiendo desde la función adios() ")