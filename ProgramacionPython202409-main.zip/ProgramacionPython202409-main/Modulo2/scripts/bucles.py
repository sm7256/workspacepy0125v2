"""
Repite la palabra "Hola" 5 veces
"""

# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')


# Bucles
# Se encargan de repetir un bloque de código un número determinado de veces

# Bucle for

# for _ in range(100):
#     print('hola')


# Bucle while
# Repite un bloque de código mientras se cumpla una condición


# n =0 # contador

# # condicion del bucle
# while n < 5:
#     print('hola')
#     n += 1 # incrementa mi contador



anio = 2001
while anio <= 2012:
    
    print(f'Informes del año {anio}')

    anio += 1 # aumentamos contador
    pass # pass es un comando que no hace nada

print('FInalizando el programa')




